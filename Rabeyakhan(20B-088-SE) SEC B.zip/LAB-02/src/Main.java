public class MainClass {
    public static void main(String[] args) {

        Login_page.user_Login();
        System.setProperty("webdriver.chrome.driver", "src/driver/chromedriver.exe");

        // Create an instance of the Product class
        Product product = new Product();

        // Call the main method of the Product class
        product.main(new String[0]);

    }
       // Create an instance of the Cart class
       Cart cart = new Cart();

    // Call the verifyCheckoutPage method of the Cart class
        cart.verifyCheckoutPage("Expected Product Name", "Expected Total Amount");
}
        //calling checkout class
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        WebDriver driver = new ChromeDriver(options);

        // Navigate to the product page
        driver.get("https://www.saucedemo.com/v1/inventory.html");

        // Find and click on a product to add it to the cart
        WebElement productToAdd = driver.findElement(By.xpath("//button[text()='ADD TO CART']"));
        productToAdd.click();

        // Find and click on another product to add it to the cart
        WebElement anotherProduct = driver.findElement(By.xpath("//button[text()='ADD TO CART']"));
        anotherProduct.click();
        // Close the browser
        driver.quit();

    }
}
}