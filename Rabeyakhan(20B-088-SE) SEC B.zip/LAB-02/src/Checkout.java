import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Checkout {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "src/driver/chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        WebDriver driver = new ChromeDriver(options);

        // Navigate to the checkout step two page
        driver.get("https://www.saucedemo.com/v1/checkout-step-two.html");

        // Click on the Finish button
        WebElement finishButton = driver.findElement(By.xpath("//button[text()='FINISH']"));
        finishButton.click();

        // Verify that the checkout complete page has opened
        String currentUrl = driver.getCurrentUrl();
        if (currentUrl.equals("https://www.saucedemo.com/v1/checkout-complete.html")) {
            System.out.println("Checkout is complete.");
        } else {
            System.out.println("Checkout failed.");
        }

        // Close the browser
        driver.quit();
    }
}
