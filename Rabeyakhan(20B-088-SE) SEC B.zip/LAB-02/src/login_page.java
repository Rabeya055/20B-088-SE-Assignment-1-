import org.openqa.selenium.By;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_page{
    public static void user_Login() {
        System.setProperty("webdriver.chrome.driver", "src/driver/chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.get("https://www.saucedemo.com");

        WebElement usernameInput = driver.findElement(By.id("user-name"));
        WebElement passwordInput = driver.findElement(By.id("password"));
        WebElement loginButton = driver.findElement(By.id("login-button"));

        usernameInput.sendKeys("your_username");
        passwordInput.sendKeys("your_password");
        loginButton.click();

        // Find the username input field
        WebElement usernameInput = driver.findElement(By.id("user-name"));

       // Find the password input field
        WebElement passwordInput = driver.findElement(By.id("password"));

       // Find the login button
        WebElement loginButton = driver.findElement(By.id("login-button"));

        driver.quit();
    }
}
