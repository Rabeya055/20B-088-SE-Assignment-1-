package driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
public class parameterized {
    import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

    public class parameterized {
        public static String userName = "standard_user";
        public static String passWord = "secret_sauce";
        public static String driverprop = "webdriver.chrome.driver";
        public static String path = "src/driver/chromedriver.exe";
        public static String statement="Hello this is my first automation project";
        public static String argument="--remote-allow-origins=*";
        public static String Url="https://www.saucedemo.com/";
        public static String expectedTitle ="Swag Labs";
        public static String standard_user="standard_user";
        public static String login_button="login-button";
        public static String result="products";
        public static String password="secret_sauce";
        public static String xpath="//span[@class='title']";
        public static String username="user-name";
        public static String Password="password";


        public static void main(String[] args) throws Exception {
            System.out.println(statement);
            try {
                //set Driver path
                System.setProperty(driverprop, path);
                ChromeOptions chromeOptions= new ChromeOptions();
                chromeOptions.addArguments(argument);
                WebDriver driver=new ChromeDriver();
                driver.manage().window().maximize();;
                driver.get(Url);
                driver.getTitle();
                String actualTitle=driver.getTitle();

                if(actualTitle.equals(expectedTitle)){
                    System.out.println("pass");}
                else{
                    System.out.println("fail");
                }
                // Enter Value in TextBoxes
                String userName = standard_user;
                WebElement usernameTextBox = driver.findElement(By.id(username));
                usernameTextBox.sendKeys(userName);

                String passWord = password;
                WebElement passWordTextBox = driver.findElement(By.id(Password));
                passWordTextBox.sendKeys(passWord);
                // Click on Button
                WebElement loginButton = driver.findElement(By.id(login_button));
                loginButton.click();
                Thread.sleep(3000);
                String expectedResult=result;
                WebElement title = driver.findElement(By.xpath(xpath));
                String actualResult=title.getText();
                if(actualTitle.equals(expectedResult)){
                    System.out.println("pass");}
                else{
                    System.out.println("fail");
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }
}
