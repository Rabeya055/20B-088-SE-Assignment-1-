package driver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
public class methods {

    public class parameterized {

            public static String userName = "standard_user";
            public static String passWord = "secret_sauce";
            public static String driverprop = "webdriver.chrome.driver";
            public static String path = "src/driver/chromedriver.exe";
            public static String statement="Hello this is my first automation project";
            public static String argument="--remote-allow-origins=*";
            public static String Url="https://www.saucedemo.com/";
            public static String expectedTitle ="Swag Labs";
            public static String standard_user="standard_user";
            public static String login_button="login-button";
            public static String result="products";
            public static String password="secret_sauce";
            public static String xpath="//span[@class='title']";
            public static String username="user-name";
            public static String Password="password";
            public static int  time=2000;
            public static WebDriver driver;
            public static void NavigateToUrl(String)throws Exception{...}
            public static void verifyTitle(String Title) throws Exception{..}
            public static void ClickElement(String identifier,String testData)throws Exception{...}
            public static void verifyElementExpectedText(String identifier,String expectedResult)throws Exception{...}


        public static void main(String[] args) throws Exception {
                System.out.println(statement);
                initiateWebBrowserSession();
                
               // public static void WaitForTime(int ns)throws Exception{...}
                //public static void InitiateWebBrowserSession()throws Exception{...}

                try {

                    //set Driver path
                    System.setProperty(driverprop, path);
                    ChromeOptions chromeOptions= new ChromeOptions();
                    chromeOptions.addArguments(argument);
                    WebDriver driver=new ChromeDriver();
                    driver.manage().window().maximize();;
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    public static void navigateToURL(String url) throws Exception {
        try {
            driver.get(url);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public static void verifyTitle(String Title) throws Exception {
        try {
            // 2. Verification of Title
            String actualTitle = driver.getTitle();
            if (actualTitle.equals(expectedTitle)) {
                System.out.println(
                        "Title Verification Passed:\n" +
                                "Expected Title: " + expectedTitle + "\n" +
                                "Actual Title: " + actualTitle);
            } else {
                System.out.println(
                        "Title Verification Failed:\n" +
                                "Expected Title: " + expectedTitle + "\n" +
                                "Actual Title: " + actualTitle);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void enterText(String indentifier, String testData) throws Exception{
        try{
            // 3. Enter Value in TextBoxes
            WebElement usernameTextBox = driver.findElement(By.id(indentifier));
            usernameTextBox.sendKeys(testData);
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public static void clickElement(String identifier) throws Exception {
        try {
            // 4. Click on Button
            WebElement loginButton = driver.findElement(By.id(identifier));
            loginButton.click();
        } catch (Exception e) {
            {
                System.out.println(e);
            }
        }
    }

}
        }

                System.out.println(printstatement);


                WebElement passWordTextBox = driver.findElement(By.id(pass));
                passWordTextBox.sendKeys(passWord);


                //Thread.sleep(time);

                // 5. Get Text from Element
                WebElement title = driver.findElement(By.xpath(textelement));
                String actualResult = title.getText();
                if (actualResult.equals(expectedResult)) {
                System.out.println(
                "Title Verification Passed:\n" +
                "Expected Title: " + expectedTitle + "\n" +
                "Actual Title: " + actualTitle);
                } else {
                System.out.println(
                "Title Verification Failed:\n" +
                "Expected Title: " + expectedTitle + "\n" +
                "Actual Title: " + actualTitle);
                }

                } catch (Exception e) {
                System.out.println(e);
                }
                }

                }
    }
