import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Cart {
    public void verifyCheckoutPage(String expectedProductName, String expectedTotalAmount) {
        System.setProperty("webdriver.chrome.driver", "src/driver/chromedriver.exe");

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        WebDriver driver = new ChromeDriver(options);

        // Navigate to the checkout page
        driver.get("https://www.saucedemo.com/v1/checkout-step-two.html");

        // Find and verify the product name on the checkout page
        WebElement productName = driver.findElement(By.className("inventory_item_name"));
        String actualProductName = productName.getText();

        if (actualProductName.equals(expectedProductName)) {
            System.out.println("Product Name: " + actualProductName);
        } else {
            System.out.println("Product Name does not match.");
        }

        // Find and verify the total amount on the checkout page
        WebElement totalAmount = driver.findElement(By.className("summary_total_label"));
        String actualTotalAmount = totalAmount.getText();

        if (actualTotalAmount.equals(expectedTotalAmount)) {
            System.out.println("Total Amount: " + actualTotalAmount);
        } else {
            System.out.println("Total Amount does not match.");
        }

        // Close the browser
        driver.quit();
    }
}
