import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Product {
    // Static variable to maintain the cart count
    private static int cartCounter = 0;

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "src/driver/chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        // Navigate to the product page
        driver.get("https://www.saucedemo.com/v1/inventory.html");

        // Find and click on a product to add it to the cart
        WebElement productToAdd = driver.findElement(By.xpath("//div[@class='inventory_item'][1]//button[text()='ADD TO CART']"));
        productToAdd.click();

        // Increment the cart counter when a product is added to the cart
        cartCounter++;

        // Display the cart count
        System.out.println("Items in Cart: " + cartCounter);

        // Close the browser
        driver.quit();
    }
}
